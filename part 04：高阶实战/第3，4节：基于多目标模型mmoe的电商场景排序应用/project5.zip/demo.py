import sys
import numpy as np

def CF(ratings_matrix):
    # 将输入转换为numpy数组
    ratings = np.array(ratings_matrix, dtype=float)
    user_count, item_count = ratings.shape
    
    # 计算用户相似度矩阵
    sim_matrix = np.zeros((user_count, user_count))
    for i in range(user_count):
        for j in range(user_count):
            if i == j:
                sim_matrix[i][j] = 1.0
                continue
            
            # 找出两个用户共同评分的物品
            common_items = np.where((ratings[i] != 0) & (ratings[j] != 0))[0]
            
            # 如果没有共同评分的物品，相似度为0
            if len(common_items) == 0:
                sim_matrix[i][j] = 0.0
                continue
            
            # 提取共同评分的物品评分
            user_i_ratings = ratings[i][common_items]
            user_j_ratings = ratings[j][common_items]
            
            # 计算皮尔逊相关系数
            if np.std(user_i_ratings) == 0 or np.std(user_j_ratings) == 0:
                sim_matrix[i][j] = 0.0
            else:
                correlation = np.corrcoef(user_i_ratings, user_j_ratings)[0, 1]
                sim_matrix[i][j] = correlation if not np.isnan(correlation) else 0.0
    
    # 预测评分
    preds = []
    for u in range(user_count):
        user_preds = []
        for i in range(item_count):
            # 如果用户已经评分
            if ratings[u][i] != 0:
                user_preds.append(0.0)
                continue
                
            # 计算分子和分母
            nume = 0.0
            deno = 0.0
            
            # 找出所有对该物品评分的其他用户
            for v in range(user_count):
                if v != u and ratings[v][i] != 0:
                    sim = sim_matrix[u][v]
                    nume += sim * ratings[v][i]
                    deno += abs(sim)
            
            # 计算预测评分
            if deno > 0:
                pred = nume / deno
                user_preds.append(round(pred, 2))
            else:
                user_preds.append(0)
        
        preds.append(user_preds)
    
    return preds


input_str = sys.stdin.read().strip()
if input_str.startswith('[') and input_str.endswith(']'):
    in_matrix = eval(input_str)
else:
    lines = input_str.strip().split('\\n')
    in_matrix = []
    for line in lines:
        if line:
            in_matrix.append(list(map(float, line.split())))

result = CF(in_matrix)
for user_preds in result:
    print(user_preds)
