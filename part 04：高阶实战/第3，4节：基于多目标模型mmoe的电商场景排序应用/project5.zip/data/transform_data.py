#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: boyu

from __future__ import absolute_import, division, print_function

import tensorflow as tf
import json
import mmh3
# step01

train_path = "170"
test_path = "180"
index_path = "index"

train_writer = tf.io.TFRecordWriter(train_path + ".tfrecord")
test_writer = tf.io.TFRecordWriter(test_path + ".tfrecord")
index_writer = open(index_path, "w")

slot = {}

names = [
    'user_id', 'item_id', 'sdk_type', 'remote_host', 'device_type', 'dtu',
    'click_goods_num', 'buy_click_num', 'goods_show_num', 'goods_click_num',
    'brand_name', 'ctr', 'cvr'
]


def mmh32hash64(str01):
    """
    使用mmh3算法计算给定字符串的64位哈希值。

    Args:
        str01 (str): 需要计算哈希值的字符串。

    Returns:
        int: 给定字符串的64位哈希值。

    """
    seed = 2021
    tmp = mmh3.hash(str01, seed=seed, signed=False)
    return tmp


def tohash(line):
    """
    将给定的 JSON 格式的字符串转换为一个哈希字符串。

    Args:
        line (str): 包含用户行为数据的 JSON 格式字符串。

    Returns:
        str: 转换后的哈希字符串，若用户特征或商品特征为 None，则返回 None。

    """
    line_json = json.loads(line)
    uid = line_json["UserId"]
    iid = line_json["ItemId"]
    label = line_json["Label"].split("$#")
    user_feature = line_json["UserFeature"].get("Feature", None)
    item_feature = line_json["ItemFeature"].get("Feature", None)
    if user_feature is None or item_feature is None:
        return
    result = []
    result.append(str(mmh32hash64("user_id=" + str(uid))))
    result.append(str(mmh32hash64("item_id=" + str(iid))))

    feature_tmp = {}
    for uf in user_feature:
        if uf["FeatureName"] not in names:
            continue
        if uf["FeatureName"] == 'sdk_type':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["StringValue"]
        if uf["FeatureName"] == 'remote_host':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["StringValue"]
        if uf["FeatureName"] == 'device_type':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["StringValue"]
        if uf["FeatureName"] == 'dtu':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["StringValue"]
        if uf["FeatureName"] == 'click_goods_num':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["FloatValue"]
        if uf["FeatureName"] == 'buy_click_num':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["FloatValue"]

    for uf in item_feature:
        if uf["FeatureName"] not in names:
            continue
        if uf["FeatureName"] == 'goods_show_num':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["FloatValue"]
        if uf["FeatureName"] == 'goods_click_num':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["FloatValue"]
        if uf["FeatureName"] == 'brand_name':
            feature_tmp[uf["FeatureName"]] = uf["FeatureValue"]["StringValue"]

    for feature_name in names:
        if feature_name in ['user_id', 'item_id', 'label']:
            continue
        w = mmh32hash64(feature_name + "=" + str(feature_tmp[feature_name]))
        result.append(str(w))
    result.append(str(label[0]) + "," + str(label[1]))

    return ",".join(result)


def ext_train_test_tohash():
    """
    将训练集和测试集的数据转换为哈希值并写入文件。

    Args:
        无

    Returns:
        无

    """
    raw_data_train = "./170"
    raw_data_val = "./180"

    raw_data_lines = open(raw_data_train, encoding='utf8')
    raw_data_write_tohash = open(raw_data_train + ".hash", 'w')
    for line in raw_data_lines:
        tmp = tohash(line)
        if tmp is not None:
            raw_data_write_tohash.write(tmp + '\n')
    raw_data_write_tohash.close()

    raw_data_lines = open(raw_data_val, encoding='utf8')
    raw_data_write_tohash = open(raw_data_val + ".hash", 'w')
    for line in raw_data_lines:
        tmp = tohash(line)
        if tmp is not None:
            raw_data_write_tohash.write(tmp + '\n')
    raw_data_write_tohash.close()


#ext_train_test_tohash()
train_file = "./170.hash"
test_file = "./180.hash"


def write_index(slot: dict, writer):
    for k, v in slot.items():
        writer.write(f"{k}\t{v}\n")


def to_tfrecord(line, writer):
    """
    将给定行数据转换为TFRecord格式并写入文件。

    Args:
        line (list): 包含样本数据的列表，每个元素对应一个特征的值。
        writer (tf.io.TFRecordWriter): TFRecord文件写入器。

    Returns:
        None

    """
    sample = {}
    for k, v in zip(names, line):

        if k == "ctr":
            sample["ctr"] = tf.train.Feature(float_list=tf.train.FloatList(
                value=[float(v)]))
            continue
        if k == "cvr":
            sample["cvr"] = tf.train.Feature(float_list=tf.train.FloatList(
                value=[float(v)]))
            continue

        vTmp = k + "=" + str(v)
        if vTmp not in slot.keys():
            slot[vTmp] = len(slot)
        value = [slot[vTmp]]
        sample[k] = tf.train.Feature(int64_list=tf.train.Int64List(
            value=value))

    sample = tf.train.Example(features=tf.train.Features(feature=sample))
    writer.write(sample.SerializeToString())


train_num = 30000
lines = open(train_file, encoding="utf8")
for i, line in enumerate(lines):
    if i > train_num:
        break
    line = line.strip().split(",")
    to_tfrecord(line, train_writer)

test_num = 3000
lines = open(test_file, encoding="utf8")
for i, line in enumerate(lines):
    if i > test_num:
        break
    line = line.strip().split(",")
    to_tfrecord(line, test_writer)

write_index(slot, index_writer)

index_writer.close()
train_writer.close()
test_writer.close()
