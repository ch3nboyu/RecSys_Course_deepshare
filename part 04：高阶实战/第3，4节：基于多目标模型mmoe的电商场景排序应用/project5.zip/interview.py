#!/usr/bin/env python
# -*- coding: utf-8 -*-
# handwritten APIs often tested in interviews
# 
# @Author: boyu
# @Date:   2025-1-31 17:21:38

import math
import numpy as np
import torch
import torch.nn as nn



def compute_roc_auc(y_true, y_scores):
    '''calculate the area under curve of ROC
    Args:
        y_true: [1, 0, 1...]
        y_scores: [0.9, 0.6, 0.3, ...]
    Returns:
        float, AUC score
    '''
    sorted_indices = np.argsort(-y_scores)
    y_true = np.array(y_true)[sorted_indices]
    pos = np.sum(y_true)
    neg = len(y_true) - pos
    # init TPR and FPR
    tpr, fpr, tp, fp = [0], [0], 0, 0
    for i in range(len(y_true)):
        if y_true[i] == 1:
            tp += 1
        else:
            fp += 1
        tpr.append(tp / pos)
        fpr.append(fp / neg)
    tpr.append(1)
    fpr.append(1)
    auc = 0.0
    for i in range(1, len(fpr)):
        auc += (fpr[i] - fpr[i - 1]) * (tpr[i] + tpr[i - 1]) / 2
    return auc

def calculate_auc(y_true, y_scores):
    '''calculate AUC using the Ranking Method
    Args:
        y_true: [1, 0, 1...]
        y_scores: [0.9, 0.6, 0.3, ...]
    Returns:
        float, AUC score
    '''
    sorted_indices = sorted(range(len(y_scores)), key=lambda i: y_scores[i])
    sorted_labels = [y_true[i] for i in sorted_indices]
    rank_sum = 0
    pos_count = sum(y_true)
    neg_count = len(y_true) - pos_count
    for i in range(len(sorted_labels)):
        if sorted_labels[i] == 1:
            rank_sum += i + 1
        
    auc = (rank_sum - pos_count*(pos_count+1)/2) / pos_count*neg_count
    return auc


class MultiHeadAttention(nn.Module):
    def __init__(self, hidden_dim, nums_head) -> None:
        super().__init__()
        self.nums_head = nums_head
        
        self.head_dim = hidden_dim // nums_head
        self.hidden_dim = hidden_dim

        self.q_proj = nn.Linear(hidden_dim, hidden_dim)
        self.k_proj = nn.Linear(hidden_dim, hidden_dim)
        self.v_proj = nn.Linear(hidden_dim, hidden_dim)
        self.o_proj = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, x, attention_mask=None):
        batch_size, seq_len, _ = x.size()

        Q = self.q_proj(x)
        K = self.k_proj(x)
        V = self.v_proj(x)

        q_state = Q.view(batch_size, seq_len, self.nums_head, self.head_dim).permute(0, 2, 1, 3)
        k_state = K.view(batch_size, seq_len, self.nums_head, self.head_dim).transpose(1, 2)
        v_state = V.view(batch_size, seq_len, self.nums_head, self.head_dim).transpose(1, 2)

        # MatMul and Scale
        attention_weight = (
            q_state @ k_state.transpose(-1, -2) / math.sqrt(self.hidden_dim)
            )
        
        # Mask (opt.)
        if attention_mask is not None:
            attention_weight = attention_weight.masked_fill(attention_mask == 0, float("-1e20"))

        # Softmax
        attention_weight = torch.softmax(attention_weight, dim=-1)
        
        output_mid = attention_weight @ v_state
        output_mid = output_mid.transpose(1, 2).contiguous()

        output = output_mid.view(batch_size, seq_len, -1)
        output = self.o_proj(output)
        return output



