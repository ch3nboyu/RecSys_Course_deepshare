# -*- coding: utf-8 -*-
# @Author : Zip
# @Moto   : Knowledge comes from decomposition
from __future__ import absolute_import, division, print_function

import tensorflow as tf
import json
# step01

train_path = "train_sample.dat"
test_path = "test_sample.dat"
index_path = "index"

train_writer = tf.io.TFRecordWriter(train_path + ".tfrecord")
test_writer = tf.io.TFRecordWriter(test_path + ".tfrecord")
index_writer = open(index_path, "w")

slot = {}


def write_index(slot: dict, writer):
    for k, v in slot.items():
        writer.write(f"{k}\t{v}\n")


def split_float(x):
    if x < 2:
        return 0
    if x < 4:
        return 1
    if x < 6:
        return 2
    if x < 8:
        return 3
    if x < 10:
        return 4
    return 5


def to_tfrecord(line, writer):
    sample = {}
    for k, v in line.items():
        if k == "label":
            sample["ctr"] = tf.train.Feature(float_list=tf.train.FloatList(
                value=[v]))
            continue
        if k == "itag4":
            v = split_float(v)

        vTmp = k + "=" + str(v)
        if vTmp not in slot.keys():
            slot[vTmp] = len(slot)
        value = [slot[vTmp]]
        sample[k] = tf.train.Feature(int64_list=tf.train.Int64List(
            value=value))

    sample = tf.train.Example(features=tf.train.Features(feature=sample))
    writer.write(sample.SerializeToString())


train_num = 30000
lines = open(train_path, encoding="utf8")
for i, line in enumerate(lines):
    if i > train_num:
        break
    line = json.loads(line.strip())
    to_tfrecord(line, train_writer)

test_num = 3000
lines = open(test_path, encoding="utf8")
for i, line in enumerate(lines):
    if i > test_num:
        break
    line = json.loads(line.strip())
    to_tfrecord(line, test_writer)

write_index(slot, index_writer)

index_writer.close()
train_writer.close()
test_writer.close()
